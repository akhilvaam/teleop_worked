#ifndef _IMU2_H_
#define _IMU2_H_
#include <Wire.h>
#include "geometry_msgs/Vector3.h"
#include <SPI.h>
#include <SparkFunLSM9DS1.h>
LSM9DS1 imu;
#define LSM9DS1_M  0x1E 
#define LSM9DS1_AG  0x6B 

bool initIMU()
{
  imu.settings.device.commInterface = IMU_MODE_I2C;
  imu.settings.device.mAddress = LSM9DS1_M;
  imu.settings.device.agAddress = LSM9DS1_AG;
  if (!imu.begin())
      return false;
  return true;
}

geometry_msgs::Vector3 readAccelerometer() 
{
   geometry_msgs::Vector3 accel;
   
  imu.readAccel();
  accel.x= imu.calcAccel(imu.ax)*9.8;
  accel.y= imu.calcAccel(imu.ay)*9.8;
  accel.z= imu.calcAccel(imu.az)*9.8;
  return accel;
}

geometry_msgs::Vector3 readGyroscope()
{
    geometry_msgs::Vector3 gyro;
    
 imu.readGyro();
 gyro.x= imu.calcGyro(imu.gx)*0.0174532925;
 gyro.y= imu.calcGyro(imu.gy)*0.0174532925;
 gyro.z= imu.calcGyro(imu.gz)*0.0174532925;
 return gyro;
}

geometry_msgs::Vector3 readMagnetometer()
{
    geometry_msgs::Vector3 mag;
    
 imu.readGyro();
 mag.x= imu.calcGyro(imu.mx)*0.000001;
 mag.y= imu.calcGyro(imu.my)*0.000001;
 mag.z= imu.calcGyro(imu.mz)*0.000001;
 return mag;
}
#endif
