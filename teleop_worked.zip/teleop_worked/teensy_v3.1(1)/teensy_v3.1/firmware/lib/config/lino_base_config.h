#ifndef SELF_E_BASE_CONFIG_H
#define SELF_E_BASE_CONFIG_H

//uncomment the base you're building
#define SELF_E_BASE DIFF_2WD

//uncomment the motor driver you're using
#define USE_L298_DRIVER

//uncomment the IMU you're using
#define USE_MPU6050_IMU

#define DEBUG 1

#define K_P 0.09 // P constant
#define K_I 0.1 // I constant
#define K_D 0.1 // D constant


//define your robot' specs here
#define MAX_RPM 75 // motor's maximum RPM
#define COUNTS_PER_REV 680 // wheel encoder's no of ticks per rev
#define WHEEL_DIAMETER 0.062 // wheel's diameter in meters
#define PWM_BITS 8 // PWM Resolution of the microcontroller
#define BASE_WIDTH 0.19 // width of the plate you are using

//=================BIGGER ROBOT SPEC (BTS7960)=============================
// #define K_P 0.05 // P constant
// #define K_I 0.9 // I constant
// #define K_D 0.08 // D constant

// define your robot' specs here
// #define MAX_RPM 45 // motor's maximum RPM
// #define COUNTS_PER_REV 4000 // wheel encoder's no of ticks per rev
// #define WHEEL_DIAMETER 0.15 // wheel's diameter in meters
// #define PWM_BITS 8 // PWM Resolution of the microcontroller
// #define BASE_WIDTH 0.32 // width of the plate you are using
//================= END OF BIGGER ROBOT SPEC =============================

/*
ROBOT ORIENTATION
         FRONT
    MOTOR1  MOTOR2
         BACK
*/

/// ENCODER PINS
#define MOTOR2_ENCODER_A 4
#define MOTOR2_ENCODER_B 5

#define MOTOR1_ENCODER_A 1
#define MOTOR1_ENCODER_B 2

//MOTOR PINS
// #ifdef USE_L298_DRIVER
#define MOTOR_DRIVER L298

#define MOTOR1_PWM_A 9
#define MOTOR2_PWM_A 10
  //#define MOTOR2_IN_A 20
#define MOTOR1_IN_A1 17
#define MOTOR1_IN_A2 16
#define MOTOR2_IN_A1 11
#define MOTOR2_IN_A2 8
 




#endif
